# PPAT — Physics Problem Animation Tool

输入中文物理运动学题目 → AI 解题分步详解 + Canvas 动画演示 + 数据图表

## 使用方法

```bash
python3 app.py
```

浏览器打开 http://localhost:8000，在右上角输入你的 DeepSeek API Key，然后输入题目即可。

API Key 可到 [platform.deepseek.com](https://platform.deepseek.com) 获取。

## 功能

- 自然语言输入物理题目
- AI 分步解题（含公式和结果）
- Canvas 动画演示运动过程（速度/加速度矢量、轨迹）
- 支持：自由落体、斜面、木板滑块、追及、碰撞、多段运动等
- 可选生成 v-t / a-t / x-t 数据图表
- 模型选择：DeepSeek V4 Flash（快）/ V4 Pro（准）

## 系统要求

- Python 3.10+
- `pip install httpx`
