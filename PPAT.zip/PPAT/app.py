import json
import os
import re
import httpx
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

BASE_DIR = Path(__file__).parent
TEMPLATE_DIR = BASE_DIR / "templates"

env_file = BASE_DIR / ".env"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip())

DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_URL = "https://api.deepseek.com/v1/chat/completions"

SYSTEM_PROMPT = """你是物理教学助手，讲解物理运动学题目并输出动画数据。必须严格输出合法 JSON。

=== JSON 结构 ===
{"已知条件":["m=2kg","v0=5m/s"],"求解目标":"...","解题步骤":[{"step":1,"title":"...","content":"...","formula":"...","result":"...","timeStart":0,"timeEnd":1.5}],"动画数据":{"motionType":"类型","objects":[...],"duration_seconds":0,"groundY":0,"annotations":[...]}}

=== 坐标系 === x右正y上正，g=10m/s²默认，ay=-g，地面y=0。

=== 运动类型 === freeFall|uniform|uniformAccel|projectile|circular|multiStage(单物体多段)|multiObject(多物体)

=== 形状shape === ball(小球)|block(方块)|plank(长木板,必须带length字段/米)|slope(斜面,必须带angle角度/度和length斜面长/米)

=== 斜面专用规则 ===
斜面左下角为基准点(x=0,y=0)，右下角(x=Lcosθ,0)，顶端(x=0, Lsinθ)。斜边从左上方斜向右下方。
滑块初始位置必须严格在斜面顶端坐标：x=斜面baseX, y=斜面baseY+Lsinθ（不是Lcosθ！不是Lcosθ！）
例：倾角30°长10m → Lcos30=8.66, Lsin30=5 → 滑块初始位置必须是(0, 5)，决不是(8.66, 5)
加速度沿斜面方向分解：a∥=g(sinθ-μcosθ)，ax=+a∥cosθ（向右为正!），ay=-a∥sinθ（向下为负!）
斜面上的contact由物理决定：滑块受支持力约束始终在斜面上（斜面加速度分量已保证这一点），但若滑块离开斜面（如抛出），则不再约束。

=== 位置规则（极其重要！必须严格遵守！）===
木板：厚0.1m，底部贴地→中心y=0.05(上表面y=0.10)，默认中心x=0（除非题目指定位置）。
板上物块：y=0.20（必须紧贴板面，块底y=0.10=板上表面）。**x坐标必须是木板左端或右端的精确值**（不是接近值！）。
  例：木板长4m中心x=0 → 左端x=-2.0，右端x=2.0 → 物块x必须是-2.0或2.0，决不能是-1.9或2.1
  物块初始速度方向决定它在哪端：vx>0放左端，vx<0放右端
地面物块：y=0.1（物块半高约0.1m，底部贴地y=0）。空中物体按题目高度。

=== 物体定义 ===
单段运动: {"label":"A","mass_kg":2,"shape":"ball","color":"#E8833A","initialPosition":{"x":0,"y":5},"initialVelocity":{"vx":0,"vy":0},"acceleration":{"ax":0,"ay":-10}}
多段运动: 顶层放initialPosition/initialVelocity，stages数组每项{"duration":5,"acceleration":{"ax":2,"ay":0},"description":"加速"}
多物体: objects数组，每个独立定义。

=== 颜色 === 单物体#E8833A，多物体依次#E8833A #4A9C6C #5B8DB8 #8B6BAE

=== 自检清单（输出前逐条核对！）===
1. 物块在木板上的x是否精确等于端点值（±2.0而不是±1.9）？
2. 物块初始y是否为0.25（不是0.2）？
3. duration_seconds是否等于解题步骤中最大的timeEnd × 1.2？
4. 解题步骤中的位移、速度数值是否与动画的initialPosition/initialVelocity/acceleration一致？
5. 木板是否明确指定了length（米）？

=== 必须遵守 ===
- JSON合法，字符串内不出现未转义双引号或换行
- stages只放duration/acceleration，initialPosition/initialVelocity只在顶层
- duration_seconds =（解题步骤中最大的timeEnd）× 1.2
- 每个物体必须有shape，plank必须有length(米)
- 板上物块y必须>木板y，不可相同或更低
- 题目隐含参数自行设定合理值，列入已知条件"""

# 模块级复用 httpx client（默认 HTTPServer 是单线程，无需加锁）
_http_client = httpx.Client(timeout=120.0, trust_env=False)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.end_headers()
            self.wfile.write((TEMPLATE_DIR / "index.html").read_bytes())
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")

    def do_POST(self):
        if self.path == "/api/solve":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(length))
                question = body.get("question", "").strip()
                model = body.get("model", "deepseek-v4-flash").strip()
                api_key = body.get("api_key", "").strip() or DEEPSEEK_API_KEY

                if not question:
                    self._json_response(400, {"success": False, "error": "请输入题目"})
                    return

                if not api_key:
                    self._json_response(500, {"success": False, "error": "请先在页面右上角输入 DeepSeek API Key"})
                    return

                result = self._call_deepseek(question, model, api_key)
                self._json_response(200, {"success": True, "data": result})

            except json.JSONDecodeError:
                self._json_response(400, {"success": False, "error": "请求格式错误"})
            except ValueError as e:
                err_msg = str(e)
                self._json_response(502 if "JSON" in err_msg else 500, {"success": False, "error": err_msg})
            except httpx.TimeoutException:
                self._json_response(504, {"success": False, "error": "AI 响应超时，请重试"})
            except Exception as e:
                self._json_response(500, {"success": False, "error": f"服务器错误: {str(e)}"})
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")

    def _json_response(self, status, data):
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode())

    def _call_deepseek(self, question, model, api_key=""):
        key = api_key or DEEPSEEK_API_KEY
        headers = {
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": question},
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.1,
        }

        # 打印请求信息
        print(f"\n{'='*60}")
        print(f"📤 发送题目 [{model}]:")
        print(f"   {question}")
        print(f"{'='*60}")

        resp = _http_client.post(DEEPSEEK_URL, headers=headers, json=payload)
        if resp.status_code == 401:
            raise ValueError("API Key 无效，请检查后重试")
        resp.raise_for_status()
        content = resp.json()["choices"][0]["message"]["content"]
        content = content.strip()
        if content.startswith("```"):
            lines = content.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            content = "\n".join(lines)

        # 打印 AI 完整返回
        print(f"\n📥 DeepSeek 返回（{len(content)} 字符）:")
        print(content)
        print(f"{'='*60}\n")

        # 尝试解析 → repair → 仍失败则直接报错，不再重试 API
        try:
            return json.loads(content)
        except json.JSONDecodeError as err:
            repaired = _repair_json(content)
            if repaired:
                try:
                    return json.loads(repaired)
                except json.JSONDecodeError:
                    pass
            raise ValueError(f"AI JSON 错误（{err.msg}）: {content[:300]}...") from err

    def log_message(self, format, *args):
        pass


def _repair_json(text):
    text = re.sub(r',\s*(\]|\})', r'\1', text)
    text = re.sub(r'"\s*\n\s*"', r'",\n"', text)
    text = re.sub(r'(\}|\])\s*\n\s*"', r'\1,\n"', text)
    text = re.sub(r'(\d)\s*\n\s*"', r'\1,\n"', text)
    return text


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    HTTPServer.allow_reuse_address = True
    server = HTTPServer(("0.0.0.0", port), Handler)
    print(f"=== 日志开始 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===")
    print(f"服务已启动 → http://localhost:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止")
        server.server_close()
